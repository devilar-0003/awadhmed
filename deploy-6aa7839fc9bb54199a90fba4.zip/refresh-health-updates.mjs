// netlify/functions/refresh-health-updates.mjs
//
// Runs once a day (see the `config.schedule` export at the bottom).
// It fetches the Press Information Bureau's "All Press Release" page
// (https://www.pib.gov.in/allRel.aspx) — an official Government of
// India source that is plain server-rendered HTML, not a JS app — and
// keeps a rolling list of the ones that look health/medical-scheme
// related. The result is cached in Netlify Blobs so the public
// `get-health-updates` function (and your website) never has to talk
// to pib.gov.in directly.
//
// Why PIB and not myscheme.gov.in / india.gov.in?
// Those two are the closest thing India has to an "official schemes
// API", but both render their scheme lists client-side in the browser
// (React/Next.js) with no documented public API, so a serverless
// function can't reliably read them. PIB's release listing, by
// contrast, is generated on the server and has been stable for years,
// which is why it's used here for a genuinely automatable daily feed.
// This deliberately does NOT try to replace your curated SCHEMES list
// (eligibility/benefit details don't change day to day) — it adds a
// "latest official updates" panel on top of it.
//
// If PIB ever changes its markup and this stops finding anything,
// the function fails safe: it leaves whatever was stored yesterday
// untouched rather than wiping the cache.

import { getStore } from "@netlify/blobs";

const SOURCE_URL = "https://www.pib.gov.in/allRel.aspx";
const STORE_NAME = "awadhmed-gov-data";
const BLOB_KEY = "health-updates";
const MAX_ITEMS_KEPT = 30;

// Bilingual keyword match, since PIB may render in English or Hindi
// depending on session defaults outside our control.
const KEYWORDS = [
  "health", "hospital", "medicine", "medicines", "drug", "pharma",
  "ayushman", "ayush", "jan aushadhi", "vaccination", "vaccine",
  "immunisation", "immunization", "maternal", "tb ", "tuberculosis",
  "nutrition", "sanitation", "disease", "cancer", "blood donation",
  "mental health", "abha", "abdm", "nhm", "pmjay", "anaemia", "anemia",
  "स्वास्थ्य", "अस्पताल", "औषधि", "टीकाकरण", "आयुष्मान", "जन औषधि",
];

function looksHealthRelated(title) {
  const t = title.toLowerCase();
  return KEYWORDS.some((k) => t.includes(k));
}

function extractReleases(html) {
  // PIB's markup wraps each release as an <a> tag pointing at
  // PressReleaseDetail.aspx?PRID=NNNNN — that URL pattern is the one
  // stable thing we rely on, rather than any particular div/class
  // structure (which has changed before and will again).
  const results = [];
  const re = /<a[^>]+href="([^"]*PressReleaseDetail\.aspx\?PRID=(\d+)[^"]*)"[^>]*>([^<]+)<\/a>/gi;
  let m;
  while ((m = re.exec(html)) !== null) {
    const [, hrefRaw, prid, titleRaw] = m;
    const title = titleRaw.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/\s+/g, " ").trim();
    if (!title) continue;
    const link = hrefRaw.startsWith("http")
      ? hrefRaw
      : `https://www.pib.gov.in/${hrefRaw.replace(/^\.?\/?/, "")}`;
    results.push({ prid, title, link });
  }
  return results;
}

export default async () => {
  const store = getStore(STORE_NAME);
  let existing = { updatedAt: null, items: [] };
  try {
    const prev = await store.get(BLOB_KEY, { type: "json" });
    if (prev) existing = prev;
  } catch {
    // no cache yet — that's fine, we start fresh
  }

  try {
    const res = await fetch(SOURCE_URL, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; AwadhMedSchemeBot/1.0; +https://awadhmed.example)",
        "Accept-Language": "en-IN,en;q=0.9",
      },
    });
    if (!res.ok) throw new Error(`PIB responded ${res.status}`);
    const html = await res.text();

    const releases = extractReleases(html).filter((r) => looksHealthRelated(r.title));

    const existingIds = new Set(existing.items.map((i) => i.prid));
    const fresh = releases.filter((r) => !existingIds.has(r.prid));

    const today = new Date().toISOString().slice(0, 10);
    const merged = [
      ...fresh.map((r) => ({ ...r, date: today })),
      ...existing.items,
    ].slice(0, MAX_ITEMS_KEPT);

    await store.setJSON(BLOB_KEY, {
      updatedAt: new Date().toISOString(),
      source: SOURCE_URL,
      items: merged,
    });

    console.log(`refresh-health-updates: found ${releases.length} health-related releases today, ${fresh.length} new, ${merged.length} total cached.`);
  } catch (err) {
    // Fail safe: keep serving yesterday's cache rather than an empty list.
    console.error("refresh-health-updates failed, keeping previous cache:", err);
  }
};

export const config = {
  schedule: "0 3 * * *", // 03:00 UTC = ~08:30 IST, once a day
};
