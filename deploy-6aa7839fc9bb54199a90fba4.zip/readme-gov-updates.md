# Daily government health updates — how this works

## What you asked for vs. what's actually possible

You asked to auto-fetch government schemes from official sites, refresh
daily, and show the latest on AwadhMed. Two things shape what could
actually be built:

1. **There's no official schemes API.** India's two schemes aggregators —
   [myscheme.gov.in](https://myscheme.gov.in) and the schemes section of
   [india.gov.in](https://www.india.gov.in/my-government/schemes/search) —
   both render their scheme lists client-side in the browser with no
   documented public API. A serverless function can't reliably scrape a
   JavaScript app like that, and it would break every time they redeploy.
2. **Scheme *details* (eligibility, benefit amount) rarely change day to
   day** — your existing curated `SCHEMES` list in the site's JS is still
   the right place for that. What genuinely benefits from a daily refresh
   is **news of new announcements, guideline updates, and scheme launches**.

So what's built here is a **"Latest from the Government" panel** inside
your existing Schemes Hub, refreshed daily from the **Press Information
Bureau** (pib.gov.in) — the Government of India's official press-release
channel, and one of the few govt sources that's plain server-rendered
HTML rather than a single-page app, which is what makes daily automation
actually reliable. Your curated scheme cards are untouched and still work
exactly as before, even if this panel is empty or the function isn't
deployed yet.

## How it works

```
Netlify Scheduled Function          Netlify Blobs           Your page
(refresh-health-updates.mjs)   -->   (health-updates)  <--  (get-health-updates.mjs)
  runs once/day, fetches PIB,        cached JSON              returns cached JSON
  filters health-related items,                                to the browser
  merges into a rolling list
```

- `netlify/functions/refresh-health-updates.mjs` — a **Scheduled
  Function** (runs daily at 03:00 UTC / ~08:30 IST). Fetches
  `pib.gov.in/allRel.aspx`, keeps releases whose title matches
  health/medicine/scheme-related keywords (checked in both English and
  Hindi, since PIB's language can vary by session), and stores up to 30
  of the most recent in Netlify Blobs. If the fetch or parse fails for
  any reason, it leaves the previous day's cache untouched instead of
  wiping it — the panel never goes blank because of a bad run.
- `netlify/functions/get-health-updates.mjs` — a normal function your
  page calls to read that cache. It never talks to pib.gov.in directly.
- The Schemes Hub markup and JS in `index.html` now include a
  `loadLiveHealthUpdates()` call (fired when the hub opens) that fills in
  the new panel, and hides itself quietly if the function isn't deployed
  or returns nothing.

## Deploying it

1. Keep `index.html`, `netlify.toml`, `package.json`, and the
   `netlify/functions/` folder together at your site's root and push to
   the Git repo connected to your Netlify site (Scheduled Functions only
   run on published deploys, not local previews).
2. Netlify installs `@netlify/blobs` automatically during the build via
   `package.json` — no extra setup needed, and Blobs works out of the box
   for any Netlify project.
3. After the first deploy, you can trigger the scheduled function
   manually to test it without waiting a day:
   `netlify functions:invoke refresh-health-updates` (via the Netlify
   CLI), or just wait for the first scheduled run and check
   **Project → Functions → refresh-health-updates → logs** in the
   Netlify dashboard.

## Things worth knowing

- **This is a best-effort scraper against a page I couldn't live-test**
  from this environment (no outbound network access here), so I can't
  guarantee PIB's markup matches exactly what the code expects on your
  first real run. It's written to fail safe either way — worst case, the
  panel just stays empty until the pattern is adjusted — but do check the
  function logs after the first scheduled run.
- The keyword filter is deliberately broad; expect the occasional
  loosely-related headline rather than a perfectly curated scheme list.
  This is a "latest updates" feed, not a replacement for your maintained
  `SCHEMES` array.
- If you eventually want the full myScheme dataset (4,700+ schemes) kept
  reliably in sync rather than just news headlines, the sanctioned path
  is to request data-sharing/API access from NeGD (the platform's
  operator, under MeitY) via myscheme.gov.in's contact page — that gives
  you a stable, permitted feed instead of a scraper that can break on any
  redesign.
