// netlify/functions/get-health-updates.mjs
//
// Simple read-only endpoint the website calls:
//   fetch('/.netlify/functions/get-health-updates')
//
// It never contacts pib.gov.in itself — it just returns whatever
// the scheduled refresh-health-updates.mjs function last cached in
// Netlify Blobs. This keeps the page fast and means a slow or
// unreachable government site can never block your visitors.

import { getStore } from "@netlify/blobs";

const STORE_NAME = "awadhmed-gov-data";
const BLOB_KEY = "health-updates";

export default async () => {
  try {
    const store = getStore(STORE_NAME);
    const data = await store.get(BLOB_KEY, { type: "json" });
    return Response.json(data || { updatedAt: null, items: [] });
  } catch (err) {
    console.error("get-health-updates failed:", err);
    return Response.json({ updatedAt: null, items: [] });
  }
};
